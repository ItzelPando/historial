
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="Logo navbar-brand" href="#"><img class="Logo" src="vistas/img/LOGO_WEB.png"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="textos">
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav me-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="tips.html"><i class="fa-solid fa-magnifying-glass"></i></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="tips.html"> <i class="bi bi-search"></i> Tips</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="services.html">Services</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#mapa">Locations</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="login.php"><i class="fa fa-user"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>