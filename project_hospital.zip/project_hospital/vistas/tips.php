
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Tips</title>
    <link rel="stylesheet" href="css/tips.css">
    <link rel="stylesheet" href="css/navbar_style.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="https://fontawesome.com/">
</head>
<body>
    <header>
        <?php include 'navbar.php';?>
    </header>
    <main>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card bg-color-1" style="display: flex; align-items: flex-start;"> 
                            <img src="img/vit.png" alt="" style="float: left; right: 25%; width: 100px; height: 250px;">
                            <h1>Vitaminas y Minerales</h1> 
                            <p>Son necesarios para que nuestro cuerpo lleve a cabo innumerables reacciones químicas a diario y se pueden obtener siguiendo una dieta variada y equilibrada, abundante en frutas y verduras, de las que se recomiendan al menos cinco piezas o raciones al día. Además, los lácteos y el pescado azul son ricos en calcio y la carne roja, mientras que los moluscos, las legumbres y los cereales, lo son en hierro.</p>
                    </div>
                    <div class="col-md-6">
                        <div class="card bg-color-2">
                            <h1>Sustancias</h1> 
                            <p>Evita el consumo de tabaco, alcohol y drogas. A lo largo del tiempo te pueden ocasionar problemas de salud.</p>
                        </div>                   
                    </div>
                    <div class="col-md-6">
                        <div class="card bg-color-3">
                        <h1>Duerme bien</h1> 
                            <p>Respeta tus horas de sueño, duerme entre 6-8 horas para que tu cuerpo descanse por completo.</p>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-color-4">
                    <h1>Actividades</h1>
                    <p>Busca actividades que ayuden a reducir el estres. Mientras estamos estresados nuestras defensas tienden bajar. Sal a caminar, respira, haz yoga.</p>
                </div>
                <div class="card bg-color-5"> <h1>hola mundo</h1></div>
            </div>
            <div class="col-md-3">
                <div class="card bg-color-6"></div>
                <div class="card bg-color-7"></div>
            </div>
            <div class="col-md-12">
                <div class="card bg-color-8"> <h1>hola mundo</h1></div>
            </div>
        </div>
    </div>
    </main>
    <footer>
        <?php include 'footer.php';?>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>
