
    <footer>
        <div class="main-container">
            <div class="component-1">
                <div class="contact">
                    <a class="nav-link" href="https://www.facebook.com/?locale=es_LA"><i class="fab fa-facebook"></i></a>
                    <a class="nav-link" href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a>
                    <a class="nav-link" href="https://twitter.com/?lang=es"><i class="fab fa-twitter"></i></a>
                </div>
                <span class="terms-conditions">Terms & Conditions</span
                ><span class="about-us">About us</span>
            </div>
            <div class="rectangle"></div>
                <span class="hospital-providence-durango">2024 por HOSPITAL PROVIDENCE DURANGO</span>
            <div class="ph-copyright-thin"></div>
        </div>
    </footer>